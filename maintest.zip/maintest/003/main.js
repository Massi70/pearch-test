function impress(pointer) {
  img.src = urls[pointer];
  // analytics
  let xmlHttp = new XMLHttpRequest();
  xmlHttp.open("GET", "http://dev.test06/index.php?id=" + pointer, true);
  xmlHttp.send(null);
}

function prev() {
  if (pointer === 0) {
    pointer = urls.length - 1;
  } else {
    pointer--;
  }
  impress(pointer);
}

function next() {
  pointer++;
  if (pointer === urls.length) {
    pointer = 0;
  }
  impress(pointer);
}

const urls = [
    "images/cat.jpg",
    "images/abstraction.jpg",
    "images/desert.jpg",
    "images/elks.jpg",
    "images/road.jpg"
  ],
  img = document.getElementById("gallery-image");
var pointer = 0;
impress(pointer);
