<?php

require __DIR__ . "/Lottery.php";

$testCases = [
    [
        'input'  => new DateTime('2018-10-8'),
        'output' => new DateTime('2018-10-9 21:30'),
    ],
    [
        'input'  => new DateTime('2018-10-9 21:20'),
        'output' => new DateTime('2018-10-9 21:30'),
    ],
    [
        'input'  => new DateTime('2018-10-9 22:00'),
        'output' => new DateTime('2018-10-14 21:30'),
    ],
    [
        'input'  => new DateTime('2018-10-15'),
        'output' => new DateTime('2018-10-16 21:30'),
    ],
];

$i = 0;
foreach ($testCases as $testCase) {
    $i++;
    $actual = Lottery::nextDate($testCase['input']);
    $expected = $testCase['output'];
    if ($actual == $expected) {
        echo "Test$i passed" . PHP_EOL;
    } else {
        echo "Test$i failed" . PHP_EOL;
        echo "Expected:" . $expected->format('Y-m-d H-i') . PHP_EOL;
        echo "Actual:" . $actual->format('Y-m-d H-i') . PHP_EOL;
    }
}
