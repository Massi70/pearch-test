<?php

class Lottery
{
    /**
     * @param null $datetime DateTime
     * @return DateTime
     */
    public static function nextDate($datetime = null)
    {
        if (is_null($datetime)) {
            $datetime = new DateTime();
        }
        $dt1 = clone $datetime;
        $dt1->modify('Tuesday this week 21:30');
        if ($dt1 < $datetime) {
            $dt1->modify('+7 days');
        }

        $dt2 = clone $datetime;
        $dt2->modify('Sunday this week 21:30');
        if ($dt2 < $datetime) {
            $dt2->modify('+7 days');
        }

        return ($dt1 < $dt2) ? $dt1 : $dt2;
    }
}
