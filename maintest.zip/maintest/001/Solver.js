var Solver = {
  compute: function(input) {
    let [operand1,operator,operand2] = input;

    // recursion
    if (Array.isArray(operand1)) {
      operand1 = this.compute(operand1);
    }
    if (Array.isArray(operand2)) {
      operand2 = this.compute(operand2);
    }

    // validation
    if (isNaN(operand1) || isNaN(operand2)) {
      throw new Error("Invalid operand");
    }

    switch (operator) {
      case "Plus":
        return operand1 + operand2;
        break;
      case "Minus":
        return operand1 - operand2;
        break;
      case "Times":
        return operand1 * operand2;
        break;
      case "Divide":
        return operand1 / operand2;
        break;
      default:
        throw new Error("Invalid operator");
    }
  }
};
