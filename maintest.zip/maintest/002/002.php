<?php

// connecting to a MySQL or PostgreSQL database
$dbConfig = [
    'driver'   => 'mysql', // 'pgsql' for Postgre
    'host'     => "localhost",
    'port'     => 3306,
    'username' => "root",
    'password' => "",
    'dbName'   => "test_db",
];
$dsn = "{$dbConfig['driver']}:"
    . "dbname={$dbConfig['dbName']};"
    . "host={$dbConfig['host']};"
    . "port={$dbConfig['port']};"
    . "charset=utf8";
$dbh = new PDO($dsn, $dbConfig['username'], $dbConfig['password']);

// getting data for id_user = 12
$query = 'SELECT `id_user`, `name`, `age`, `job_title`, `inserted_on`, `last_updated`'
    . ' FROM `user`'
    . ' WHERE `id_user` = ?';
$stmt = $dbh->prepare($query);
$stmt->execute([12]);
$data = $stmt->fetchAll(PDO::FETCH_ASSOC);

// writing new record with data from POST request
$name = $_POST['name'];
$age = $_POST['age'];
$jobTitle = $_POST['job_title'];
$insertedON = time();
$lastUpdated = null;

$query = 'INSERT INTO user'
    . '(`name`, `age`, `job_title`, `inserted_on`, `last_updated`)'
    . ' VALUES (?, ?, ?, ?, ?)';
$stmt = $dbh->prepare($query);
$stmt->execute([$name, $age, $jobTitle, $insertedON, $lastUpdated]);
